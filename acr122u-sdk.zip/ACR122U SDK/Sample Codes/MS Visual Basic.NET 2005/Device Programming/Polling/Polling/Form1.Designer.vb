<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.bConnect = New System.Windows.Forms.Button
        Me.bInit = New System.Windows.Forms.Button
        Me.cbReader = New System.Windows.Forms.ComboBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.gbPollOpt = New System.Windows.Forms.GroupBox
        Me.bSetPollOpt = New System.Windows.Forms.Button
        Me.bGetPollOpt = New System.Windows.Forms.Button
        Me.gbPollInt = New System.Windows.Forms.GroupBox
        Me.opt500 = New System.Windows.Forms.RadioButton
        Me.opt250 = New System.Windows.Forms.RadioButton
        Me.cbOpt7 = New System.Windows.Forms.CheckBox
        Me.cbOpt6 = New System.Windows.Forms.CheckBox
        Me.cbOpt5 = New System.Windows.Forms.CheckBox
        Me.cbOpt4 = New System.Windows.Forms.CheckBox
        Me.cbOpt3 = New System.Windows.Forms.CheckBox
        Me.cbOpt2 = New System.Windows.Forms.CheckBox
        Me.cbOpt1 = New System.Windows.Forms.CheckBox
        Me.bStartPoll = New System.Windows.Forms.Button
        Me.statusBar = New System.Windows.Forms.StatusStrip
        Me.tsMsg1 = New System.Windows.Forms.ToolStripStatusLabel
        Me.tsMsg2 = New System.Windows.Forms.ToolStripStatusLabel
        Me.tsMsg3 = New System.Windows.Forms.ToolStripStatusLabel
        Me.tsMsg4 = New System.Windows.Forms.ToolStripStatusLabel
        Me.pollTimer = New System.Windows.Forms.Timer(Me.components)
        Me.mMsg = New System.Windows.Forms.RichTextBox
        Me.bReset = New System.Windows.Forms.Button
        Me.bClear = New System.Windows.Forms.Button
        Me.bQuit = New System.Windows.Forms.Button
        Me.gbPollOpt.SuspendLayout()
        Me.gbPollInt.SuspendLayout()
        Me.statusBar.SuspendLayout()
        Me.SuspendLayout()
        '
        'bConnect
        '
        Me.bConnect.Location = New System.Drawing.Point(150, 71)
        Me.bConnect.Name = "bConnect"
        Me.bConnect.Size = New System.Drawing.Size(123, 23)
        Me.bConnect.TabIndex = 7
        Me.bConnect.Text = "Connect"
        Me.bConnect.UseVisualStyleBackColor = True
        '
        'bInit
        '
        Me.bInit.Location = New System.Drawing.Point(150, 42)
        Me.bInit.Name = "bInit"
        Me.bInit.Size = New System.Drawing.Size(123, 23)
        Me.bInit.TabIndex = 6
        Me.bInit.Text = "Initialize"
        Me.bInit.UseVisualStyleBackColor = True
        '
        'cbReader
        '
        Me.cbReader.FormattingEnabled = True
        Me.cbReader.Location = New System.Drawing.Point(93, 15)
        Me.cbReader.Name = "cbReader"
        Me.cbReader.Size = New System.Drawing.Size(180, 21)
        Me.cbReader.TabIndex = 5
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(75, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Select Reader"
        '
        'gbPollOpt
        '
        Me.gbPollOpt.Controls.Add(Me.bSetPollOpt)
        Me.gbPollOpt.Controls.Add(Me.bGetPollOpt)
        Me.gbPollOpt.Controls.Add(Me.gbPollInt)
        Me.gbPollOpt.Controls.Add(Me.cbOpt7)
        Me.gbPollOpt.Controls.Add(Me.cbOpt6)
        Me.gbPollOpt.Controls.Add(Me.cbOpt5)
        Me.gbPollOpt.Controls.Add(Me.cbOpt4)
        Me.gbPollOpt.Controls.Add(Me.cbOpt3)
        Me.gbPollOpt.Controls.Add(Me.cbOpt2)
        Me.gbPollOpt.Controls.Add(Me.cbOpt1)
        Me.gbPollOpt.Location = New System.Drawing.Point(15, 100)
        Me.gbPollOpt.Name = "gbPollOpt"
        Me.gbPollOpt.Size = New System.Drawing.Size(258, 270)
        Me.gbPollOpt.TabIndex = 8
        Me.gbPollOpt.TabStop = False
        Me.gbPollOpt.Text = "Polling Options"
        '
        'bSetPollOpt
        '
        Me.bSetPollOpt.Location = New System.Drawing.Point(124, 229)
        Me.bSetPollOpt.Name = "bSetPollOpt"
        Me.bSetPollOpt.Size = New System.Drawing.Size(116, 23)
        Me.bSetPollOpt.TabIndex = 13
        Me.bSetPollOpt.Text = "Set Polling Option"
        Me.bSetPollOpt.UseVisualStyleBackColor = True
        '
        'bGetPollOpt
        '
        Me.bGetPollOpt.Location = New System.Drawing.Point(124, 200)
        Me.bGetPollOpt.Name = "bGetPollOpt"
        Me.bGetPollOpt.Size = New System.Drawing.Size(116, 23)
        Me.bGetPollOpt.TabIndex = 12
        Me.bGetPollOpt.Text = "Get Polling Option"
        Me.bGetPollOpt.UseVisualStyleBackColor = True
        '
        'gbPollInt
        '
        Me.gbPollInt.Controls.Add(Me.opt500)
        Me.gbPollInt.Controls.Add(Me.opt250)
        Me.gbPollInt.Location = New System.Drawing.Point(18, 189)
        Me.gbPollInt.Name = "gbPollInt"
        Me.gbPollInt.Size = New System.Drawing.Size(89, 65)
        Me.gbPollInt.TabIndex = 7
        Me.gbPollInt.TabStop = False
        Me.gbPollInt.Text = "Poll Interval"
        '
        'opt500
        '
        Me.opt500.AutoSize = True
        Me.opt500.Location = New System.Drawing.Point(9, 42)
        Me.opt500.Name = "opt500"
        Me.opt500.Size = New System.Drawing.Size(71, 17)
        Me.opt500.TabIndex = 3
        Me.opt500.TabStop = True
        Me.opt500.Text = "500 msec"
        Me.opt500.UseVisualStyleBackColor = True
        '
        'opt250
        '
        Me.opt250.AutoSize = True
        Me.opt250.Location = New System.Drawing.Point(9, 17)
        Me.opt250.Name = "opt250"
        Me.opt250.Size = New System.Drawing.Size(71, 17)
        Me.opt250.TabIndex = 2
        Me.opt250.TabStop = True
        Me.opt250.Text = "250 msec"
        Me.opt250.UseVisualStyleBackColor = True
        '
        'cbOpt7
        '
        Me.cbOpt7.AutoSize = True
        Me.cbOpt7.Location = New System.Drawing.Point(18, 166)
        Me.cbOpt7.Name = "cbOpt7"
        Me.cbOpt7.Size = New System.Drawing.Size(148, 17)
        Me.cbOpt7.TabIndex = 6
        Me.cbOpt7.Text = "Detect FeliCa 242K Cards"
        Me.cbOpt7.UseVisualStyleBackColor = True
        '
        'cbOpt6
        '
        Me.cbOpt6.AutoSize = True
        Me.cbOpt6.Location = New System.Drawing.Point(18, 143)
        Me.cbOpt6.Name = "cbOpt6"
        Me.cbOpt6.Size = New System.Drawing.Size(148, 17)
        Me.cbOpt6.TabIndex = 5
        Me.cbOpt6.Text = "Detect FeliCa 212K Cards"
        Me.cbOpt6.UseVisualStyleBackColor = True
        '
        'cbOpt5
        '
        Me.cbOpt5.AutoSize = True
        Me.cbOpt5.Location = New System.Drawing.Point(18, 120)
        Me.cbOpt5.Name = "cbOpt5"
        Me.cbOpt5.Size = New System.Drawing.Size(121, 17)
        Me.cbOpt5.TabIndex = 4
        Me.cbOpt5.Text = "Detect Topaz Cards"
        Me.cbOpt5.UseVisualStyleBackColor = True
        '
        'cbOpt4
        '
        Me.cbOpt4.AutoSize = True
        Me.cbOpt4.Location = New System.Drawing.Point(18, 97)
        Me.cbOpt4.Name = "cbOpt4"
        Me.cbOpt4.Size = New System.Drawing.Size(176, 17)
        Me.cbOpt4.TabIndex = 3
        Me.cbOpt4.Text = "Detect ISO14443 Type B Cards"
        Me.cbOpt4.UseVisualStyleBackColor = True
        '
        'cbOpt3
        '
        Me.cbOpt3.AutoSize = True
        Me.cbOpt3.Location = New System.Drawing.Point(18, 74)
        Me.cbOpt3.Name = "cbOpt3"
        Me.cbOpt3.Size = New System.Drawing.Size(176, 17)
        Me.cbOpt3.TabIndex = 2
        Me.cbOpt3.Text = "Detect ISO14443 Type A Cards"
        Me.cbOpt3.UseVisualStyleBackColor = True
        '
        'cbOpt2
        '
        Me.cbOpt2.AutoSize = True
        Me.cbOpt2.Location = New System.Drawing.Point(18, 51)
        Me.cbOpt2.Name = "cbOpt2"
        Me.cbOpt2.Size = New System.Drawing.Size(155, 17)
        Me.cbOpt2.TabIndex = 1
        Me.cbOpt2.Text = "Automatic ATS  Generation"
        Me.cbOpt2.UseVisualStyleBackColor = True
        '
        'cbOpt1
        '
        Me.cbOpt1.AutoSize = True
        Me.cbOpt1.Location = New System.Drawing.Point(18, 28)
        Me.cbOpt1.Name = "cbOpt1"
        Me.cbOpt1.Size = New System.Drawing.Size(134, 17)
        Me.cbOpt1.TabIndex = 0
        Me.cbOpt1.Text = "Automatic PICC Polling"
        Me.cbOpt1.UseVisualStyleBackColor = True
        '
        'bStartPoll
        '
        Me.bStartPoll.Location = New System.Drawing.Point(18, 382)
        Me.bStartPoll.Name = "bStartPoll"
        Me.bStartPoll.Size = New System.Drawing.Size(255, 23)
        Me.bStartPoll.TabIndex = 9
        Me.bStartPoll.Text = "Start Polling"
        Me.bStartPoll.UseVisualStyleBackColor = True
        '
        'statusBar
        '
        Me.statusBar.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsMsg1, Me.tsMsg2, Me.tsMsg3, Me.tsMsg4})
        Me.statusBar.Location = New System.Drawing.Point(0, 425)
        Me.statusBar.Name = "statusBar"
        Me.statusBar.Size = New System.Drawing.Size(614, 22)
        Me.statusBar.TabIndex = 19
        Me.statusBar.Text = "StatusStrip1"
        '
        'tsMsg1
        '
        Me.tsMsg1.AutoSize = False
        Me.tsMsg1.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.tsMsg1.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken
        Me.tsMsg1.Name = "tsMsg1"
        Me.tsMsg1.Size = New System.Drawing.Size(100, 17)
        Me.tsMsg1.Text = "Card Type"
        '
        'tsMsg2
        '
        Me.tsMsg2.AutoSize = False
        Me.tsMsg2.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.tsMsg2.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken
        Me.tsMsg2.Name = "tsMsg2"
        Me.tsMsg2.Size = New System.Drawing.Size(180, 17)
        '
        'tsMsg3
        '
        Me.tsMsg3.AutoSize = False
        Me.tsMsg3.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.tsMsg3.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken
        Me.tsMsg3.Name = "tsMsg3"
        Me.tsMsg3.Size = New System.Drawing.Size(100, 17)
        Me.tsMsg3.Text = "Card Status"
        '
        'tsMsg4
        '
        Me.tsMsg4.AutoSize = False
        Me.tsMsg4.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.tsMsg4.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken
        Me.tsMsg4.Name = "tsMsg4"
        Me.tsMsg4.Size = New System.Drawing.Size(180, 17)
        Me.tsMsg4.Text = " "
        '
        'pollTimer
        '
        '
        'mMsg
        '
        Me.mMsg.Location = New System.Drawing.Point(279, 12)
        Me.mMsg.Name = "mMsg"
        Me.mMsg.Size = New System.Drawing.Size(325, 355)
        Me.mMsg.TabIndex = 43
        Me.mMsg.Text = ""
        '
        'bReset
        '
        Me.bReset.Location = New System.Drawing.Point(396, 382)
        Me.bReset.Name = "bReset"
        Me.bReset.Size = New System.Drawing.Size(114, 23)
        Me.bReset.TabIndex = 41
        Me.bReset.Text = "Reset"
        Me.bReset.UseVisualStyleBackColor = True
        '
        'bClear
        '
        Me.bClear.Location = New System.Drawing.Point(279, 382)
        Me.bClear.Name = "bClear"
        Me.bClear.Size = New System.Drawing.Size(111, 23)
        Me.bClear.TabIndex = 40
        Me.bClear.Text = "Clear"
        Me.bClear.UseVisualStyleBackColor = True
        '
        'bQuit
        '
        Me.bQuit.Location = New System.Drawing.Point(516, 382)
        Me.bQuit.Name = "bQuit"
        Me.bQuit.Size = New System.Drawing.Size(88, 23)
        Me.bQuit.TabIndex = 42
        Me.bQuit.Text = "Quit"
        Me.bQuit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(614, 447)
        Me.Controls.Add(Me.mMsg)
        Me.Controls.Add(Me.bReset)
        Me.Controls.Add(Me.bClear)
        Me.Controls.Add(Me.bQuit)
        Me.Controls.Add(Me.statusBar)
        Me.Controls.Add(Me.bStartPoll)
        Me.Controls.Add(Me.gbPollOpt)
        Me.Controls.Add(Me.bConnect)
        Me.Controls.Add(Me.bInit)
        Me.Controls.Add(Me.cbReader)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.gbPollOpt.ResumeLayout(False)
        Me.gbPollOpt.PerformLayout()
        Me.gbPollInt.ResumeLayout(False)
        Me.gbPollInt.PerformLayout()
        Me.statusBar.ResumeLayout(False)
        Me.statusBar.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents bConnect As System.Windows.Forms.Button
    Friend WithEvents bInit As System.Windows.Forms.Button
    Friend WithEvents cbReader As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents gbPollOpt As System.Windows.Forms.GroupBox
    Friend WithEvents cbOpt7 As System.Windows.Forms.CheckBox
    Friend WithEvents cbOpt6 As System.Windows.Forms.CheckBox
    Friend WithEvents cbOpt5 As System.Windows.Forms.CheckBox
    Friend WithEvents cbOpt4 As System.Windows.Forms.CheckBox
    Friend WithEvents cbOpt3 As System.Windows.Forms.CheckBox
    Friend WithEvents cbOpt2 As System.Windows.Forms.CheckBox
    Friend WithEvents cbOpt1 As System.Windows.Forms.CheckBox
    Friend WithEvents gbPollInt As System.Windows.Forms.GroupBox
    Friend WithEvents bSetPollOpt As System.Windows.Forms.Button
    Friend WithEvents bGetPollOpt As System.Windows.Forms.Button
    Friend WithEvents opt500 As System.Windows.Forms.RadioButton
    Friend WithEvents opt250 As System.Windows.Forms.RadioButton
    Friend WithEvents bStartPoll As System.Windows.Forms.Button
    Friend WithEvents statusBar As System.Windows.Forms.StatusStrip
    Friend WithEvents tsMsg1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents tsMsg2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents tsMsg3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents tsMsg4 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents pollTimer As System.Windows.Forms.Timer
    Friend WithEvents mMsg As System.Windows.Forms.RichTextBox
    Friend WithEvents bReset As System.Windows.Forms.Button
    Friend WithEvents bClear As System.Windows.Forms.Button
    Friend WithEvents bQuit As System.Windows.Forms.Button

End Class
